---
name: inline-code-editor
description: "Show an editable, runnable code editor inline in chat for Python, JavaScript, SQL and Java, with syntax colors, line-by-line code review, and optional practice problems with tests. Use when the user wants to write, run, check or practice code in an editor inside the conversation."
---

# Inline code editor

Goal: when the user wants to write, run or check code, show an editor cell directly in the chat. They can type, run, select lines and attach comments, and press Send to Claude so you can review the code line by line. They never leave the conversation. It works in the web and mobile Claude apps wherever inline widgets render, so nothing needs installing.

## What runs where

| Language | Where it runs |
| --- | --- |
| Python | In the cell, on the user's device (Skulpt) |
| JavaScript | In the cell, in a Web Worker, 4 second limit |
| SQL (SQLite) | In the cell, sql.js in a Web Worker, 4 second limit. If workers or WebAssembly are blocked it falls back to the main thread with no limit and the cell says so |
| Java | Not in the cell. Run asks you to compile and run it with javac in your workspace, and you show the verdict in a new cell |

Requirements: your inline widget tool (called `show_widget` where available) and internet access for the user's browser, because the editor and engines load from jsDelivr. Java also needs a shell with `java` and `javac` in your workspace. If you have no shell, say so plainly for Java and review the code by reading it. Never invent output you did not run.

## Starting

When the skill triggers, show a blank editor right away. Do not ask setup questions first.

- Use the language the user named. If they named none, open Python; the cell has a language picker.
- If the user pasted code, load it with `code` so it is already in the editor.
- Call the widget tool's setup guide (module `interactive`) once, silently, before the first cell.
- In chat, add one or two sentences: what the cell is and one thing to try (write something and press Run, or select lines and add a comment, then Send to Claude).

## Cell template

Keep every cell this short. Only the config changes.

```html
<h2 class="sr-only">One sentence describing the cell for screen readers</h2>
<div id="app"></div>
<script src="https://cdn.jsdelivr.net/gh/OmarOzalp/codepad@4a90250b4f06a3ebc3a6263868ca3e0eeeb9532a/codepad.js"></script>
<script>
if (window.CodePad) CodePad.mount(document.getElementById("app"), { sandbox: true, lang: "python" });
else document.getElementById("app").textContent = "The code editor could not load.";
</script>
```

Always load by commit SHA as shown, never `@main` (jsDelivr caches branches for hours). Keep widget code free of comments. The component uses CSS variables only, so dark mode works.

What the user gets: a line-numbered editor with syntax colors in light and dark themes and auto-indent (Enter keeps the indent, Tab and Shift+Tab indent and dedent selected lines, Ctrl or Cmd+Enter runs). Buttons: Run, Comment on selection (select lines, type a note, Add or Add and send to Claude), Reset, and Send to Claude. Problem cells add a Problem and Scratchpad tab, Submit with a verdict (Accepted, Wrong answer, Time limit exceeded, Compile error, Runtime error, with milliseconds), and Hint.

## Editor-only config

`{ sandbox: true, lang: "python" | "javascript" | "sql" | "java" }`. Optional: `code` (load the user's code), `starter` (what Reset restores), `notes` (see Review loop), `limit` (ms), `title`.

The editor-only cell shows a language picker, and each language remembers its own code while the user switches. Python, JavaScript and SQL print output (SQL shows a result table) under the editor. For SQL the default starter creates a small table and selects from it, and every Run starts from an empty database, so the code should create its own tables.

## Review loop (a message starting "Please review my")

The message contains their code, the last result, and any line comments. Respond in this order:

1. Answer each comment directly and briefly.
2. Show their exact code again in a NEW cell with `code` set to what they sent and `notes` attached: `[{ line, type: "issue" | "praise" | "tip", text }]`. Line numbers are 1-based and must match the code exactly, counting blank lines, so count carefully. Mix praise with fixes: what is good, what is wrong, what to tweak, and why it matters. Keep `starter` as the original so Reset works.
3. In chat, name the one thing to fix first. If the user is practicing, ask one or two follow-up questions (complexity, an edge case, a variation) and point at the line instead of writing the corrected solution. If they are just writing code and ask for a fix, give it.

## Java: Run asks you (a message starting "Please run my Java code")

The message has the code, a class name, and a mode: `main` (run the main method), `run` (sample tests) or `submit` (all tests).

1. Write a JSON config to a temp file: `{ "className": "...", "code": "...", "mode": "...", "tests": [...], "limit": 5000 }`. For `main` there are no tests. For `run` and `submit` use the tests from the problem cell you showed earlier.
2. Run `python3 scripts/run_java.py config.json` (the script is in this skill's folder).
3. Show a NEW cell with the same code and `result` set to the JSON the script printed. In chat give the verdict and the first thing to look at, in one or two sentences. Do not paste the JSON.

The script compiles with javac, auto-detects the public class name, runs the tests in a harness, captures printed output, and reports Compile error, Runtime error, Time limit exceeded, Wrong answer, Accepted or Sample tests passed. Milliseconds include JVM start-up, so expect a few hundred. Java test bodies are Java statements with `assertEquals(expected, actual)`, `assertTrue(cond, msg)` and `assertThrows(Type.class, () -> { ... })` in scope. Use the same numeric type on both sides of `assertEquals` (an int against a long fails). Arrays compare by content.

## Practice problems (only when the user asks to practice)

Pick one problem at a time at the user's level. Write the description, examples, starter, 3 hints that escalate, a reference solution, and 6 to 9 tests. Cover a normal case, a tricky case, an edge (empty, one element, boundary), an error case if relevant, and a speed test sized so the naive approach is slow but the right one is fast (mark speed and edge tests hidden). Give each test a plain-English name, because the name is what the user reads when it fails.

Before showing a cell, run the reference solution against your tests in your workspace if you have a shell (`python3`, `node`, `sqlite3`, or `run_java.py`), and make sure the starter fails. Never show a cell whose reference you have not checked. Then give the task in two or three sentences in chat and one thing to do first, ideally tracing a small example by hand. Do not paste the solution.

Config: `title`, `difficulty`, `lang`, `description` (blank line between paragraphs), `examples: [{ input, output, why }]`, `starter`, `hints`, `solution` (shown only after the last hint and a confirm click), `tests`. A test is `[name, body]`; a third element `true` hides it until Submit.

- Python tests: `assert cond, 'message'` statements, unindented. Prefer `+` and `str()` over f-strings in test messages.
- JavaScript tests: `assert(cond, msg)` and `deepEqual(a, b)`.
- SQL: set `setup` (schema and data as SQL), `schema` (text shown to the learner), and `starter`. A test body is either a JavaScript check using `rows` (array of arrays), `cols`, `assert` and `deepEqual`, or an object `{ cols: [...], rows: [[...]], ordered: false, setup: "extra SQL" }`. Row order is ignored unless `ordered` is true. A test's `setup` runs after the problem's, so use it for empty-table and edge-case data.
- Java: statements as above, run through the script. Set `className` if it is not `Solution`.

Track which problems were solved, hints used, and recurring habits. Mention a recurring habit once, kindly, and move on. If they pass with no hints, say so and move up a level; if they struggle, stay on the same idea with a smaller problem.

## Engine facts

- Python (Skulpt): classes, inheritance, `super().__init__`, `raise ValueError("msg")`, try/except, dict, list, set, enumerate and sorted work. f-strings are not guaranteed. No numpy, third-party packages, `input()`, files or network. The standard library is partial, so check `collections`, `heapq`, `itertools`, `math`, `re` and `random` before relying on them. Keep inputs small because it is slow on big loops.
- JavaScript: plain JS in a worker, no DOM, output through `console.log`.
- SQL: SQLite 3.54, not MySQL or Postgres. Window functions, CTEs, recursive CTEs, JSON functions, and RIGHT and FULL JOIN work. `ILIKE` does not exist. Only the last statement's rows are shown.
- Java: real JDK in your workspace. Each run starts fresh.

## If the cell does not load

If the user says the cell shows "The code editor could not load" or nothing runs, tell them in one line and put the code in a normal code block instead, reviewing it in plain chat. If a page or artifact tool is available, you can instead build a page that inlines the same `codepad.js`.

## Style

Teach one idea at a time, intuition first, with small concrete examples. Be encouraging but specific. In practice mode, never write the full solution unprompted. Do not assume anything about the user's goals beyond what they have said.
