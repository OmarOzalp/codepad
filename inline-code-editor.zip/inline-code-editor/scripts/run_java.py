#!/usr/bin/env python3
"""Compile and run Java code with javac, then print a JSON result for an inline editor cell.

Usage: python3 run_java.py config.json

config.json:
  className  the class the code defines (default "Solution"; auto-detected from the code if it differs)
  code       the Java source the user wrote
  mode       "run" (visible tests), "submit" (all tests), or "main" (run the main method, no tests)
  tests      [[name, java statements, hidden?], ...]  (ignored in main mode)
  limit      milliseconds allowed for the program to run (default 5000, includes JVM start-up)

Test bodies are Java statements. These helpers are in scope:
  assertTrue(cond, msg)   assertEquals(expected, actual)   assertThrows(Type.class, () -> { ... })
Arrays are compared by content. Anything the code prints inside a test is captured as output.

Prints one JSON object:
  {verdict, pass, total, ms, error, stdout, mode, tests: [{name, ok, ran, msg, hidden}]}
The object can be passed as `result` to CodePad.mount.
"""
import base64
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time

HARNESS = r'''
import java.io.*;
import java.util.*;

public class Harness {
    interface Body { void run() throws Throwable; }
    static class Fail extends RuntimeException { Fail(String m) { super(m); } }
    static final PrintStream REAL = new PrintStream(new FileOutputStream(FileDescriptor.out), true);
    static final StringBuilder USER = new StringBuilder();

    static String show(Object o) {
        if (o == null) return "null";
        if (o instanceof Object[]) return Arrays.deepToString((Object[]) o);
        if (o instanceof int[]) return Arrays.toString((int[]) o);
        if (o instanceof long[]) return Arrays.toString((long[]) o);
        if (o instanceof double[]) return Arrays.toString((double[]) o);
        if (o instanceof char[]) return Arrays.toString((char[]) o);
        if (o instanceof boolean[]) return Arrays.toString((boolean[]) o);
        if (o instanceof byte[]) return Arrays.toString((byte[]) o);
        if (o instanceof short[]) return Arrays.toString((short[]) o);
        if (o instanceof float[]) return Arrays.toString((float[]) o);
        if (o instanceof String) return "\"" + o + "\"";
        return String.valueOf(o);
    }

    static boolean same(Object a, Object b) {
        if (a == null || b == null) return a == b;
        if (a instanceof Object[] && b instanceof Object[]) return Arrays.deepEquals((Object[]) a, (Object[]) b);
        if (a instanceof int[] && b instanceof int[]) return Arrays.equals((int[]) a, (int[]) b);
        if (a instanceof long[] && b instanceof long[]) return Arrays.equals((long[]) a, (long[]) b);
        if (a instanceof double[] && b instanceof double[]) return Arrays.equals((double[]) a, (double[]) b);
        if (a instanceof char[] && b instanceof char[]) return Arrays.equals((char[]) a, (char[]) b);
        if (a instanceof boolean[] && b instanceof boolean[]) return Arrays.equals((boolean[]) a, (boolean[]) b);
        if (a instanceof byte[] && b instanceof byte[]) return Arrays.equals((byte[]) a, (byte[]) b);
        if (a instanceof short[] && b instanceof short[]) return Arrays.equals((short[]) a, (short[]) b);
        if (a instanceof float[] && b instanceof float[]) return Arrays.equals((float[]) a, (float[]) b);
        return a.equals(b);
    }

    static void assertTrue(boolean c, String m) { if (!c) throw new Fail(m); }
    static void assertTrue(boolean c) { if (!c) throw new Fail("the condition was false"); }
    static void assertEquals(Object expected, Object actual) {
        if (!same(expected, actual)) throw new Fail("expected " + show(expected) + " but got " + show(actual));
    }
    static void assertEquals(Object expected, Object actual, String m) {
        if (!same(expected, actual)) throw new Fail(m + " (expected " + show(expected) + " but got " + show(actual) + ")");
    }
    static void assertThrows(Class<? extends Throwable> type, Body b) {
        try { b.run(); }
        catch (Throwable x) {
            if (type.isInstance(x)) return;
            throw new Fail("expected " + type.getSimpleName() + " but got " + x.getClass().getSimpleName());
        }
        throw new Fail("expected " + type.getSimpleName() + " but nothing was thrown");
    }

    static String clean(String s) { return s == null ? "assertion failed" : s.replace("\r", " ").replace("\n", " "); }

    static void test(int idx, Body b) {
        PrintStream old = System.out;
        ByteArrayOutputStream buf = new ByteArrayOutputStream();
        System.setOut(new PrintStream(buf, true));
        String line;
        try { b.run(); line = "@@P|" + idx; }
        catch (Fail f) { line = "@@F|" + idx + "|" + clean(f.getMessage()); }
        catch (Throwable t) { line = "@@F|" + idx + "|" + t.getClass().getSimpleName() + (t.getMessage() != null ? ": " + clean(t.getMessage()) : ""); }
        finally { System.setOut(old); }
        USER.append(buf.toString());
        REAL.println(line);
    }

    public static void main(String[] args) throws Exception {
//TESTS//
        REAL.println("@@O|" + Base64.getEncoder().encodeToString(USER.toString().getBytes("UTF-8")));
    }
}
'''


def detect_class(code, fallback):
    m = re.search(r'public\s+(?:final\s+|abstract\s+|sealed\s+)*(?:class|interface|enum|record)\s+(\w+)', code)
    return m.group(1) if m else fallback


def clip(text, limit=4000):
    text = text or ""
    return text if len(text) <= limit else text[:limit] + "\n... (output cut)"


def tidy_javac(text, tmp, name):
    text = text.replace(tmp + os.sep, "").replace(tmp, "")
    lines = [l for l in text.splitlines() if not l.startswith("Picked up ") and not re.match(r"^\d+ errors?$", l.strip())]
    return "\n".join(lines[:30]).strip()


def result(**kw):
    base = {"verdict": "Finished", "pass": 0, "total": 0, "ms": 0, "error": None, "stdout": "", "mode": "run", "tests": []}
    base.update(kw)
    return base


def run_cmd(cmd, cwd, timeout_s):
    t0 = time.time()
    try:
        p = subprocess.run(cmd, cwd=cwd, capture_output=True, timeout=timeout_s)
        return p.returncode, p.stdout.decode("utf-8", "replace"), p.stderr.decode("utf-8", "replace"), (time.time() - t0) * 1000, False
    except subprocess.TimeoutExpired as e:
        out = (e.stdout or b"").decode("utf-8", "replace") if isinstance(e.stdout, (bytes, bytearray)) else (e.stdout or "")
        err = (e.stderr or b"").decode("utf-8", "replace") if isinstance(e.stderr, (bytes, bytearray)) else (e.stderr or "")
        return -1, out, err, (time.time() - t0) * 1000, True


def main():
    if len(sys.argv) != 2:
        print(__doc__)
        sys.exit(2)
    cfg = json.load(open(sys.argv[1]))
    mode = cfg.get("mode", "run")
    code = cfg.get("code", "")
    limit = int(cfg.get("limit", 5000))
    cls = detect_class(code, cfg.get("className") or ("Main" if mode == "main" else "Solution"))
    tests = [] if mode == "main" else [t for t in cfg.get("tests", []) if mode == "submit" or not (len(t) > 2 and t[2])]

    if not shutil.which("javac") or not shutil.which("java"):
        print(json.dumps(result(verdict="Runtime error", mode=mode, error="Java is not installed in this workspace, so the code could not be run.")))
        return

    tmp = tempfile.mkdtemp(prefix="cpjava_")
    try:
        src = os.path.join(tmp, cls + ".java")
        out = os.path.join(tmp, "out")
        os.makedirs(out)
        open(src, "w", encoding="utf-8").write(code)

        rc, so, se, ms, to = run_cmd(["javac", "-encoding", "UTF-8", "-Xlint:none", "-d", out, src], tmp, 60)
        if rc != 0:
            print(json.dumps(result(verdict="Compile error", mode=mode, total=len(tests), error=tidy_javac(se or so, tmp, cls) or "javac failed", tests=[{"name": t[0], "ok": False, "ran": False, "msg": "", "hidden": bool(len(t) > 2 and t[2])} for t in tests])))
            return

        java_base = ["java", "-Xmx256m", "-XX:+UseSerialGC", "-Xshare:auto", "-cp", out]

        if mode == "main":
            rc, so, se, ms, to = run_cmd(java_base + [cls], tmp, limit / 1000.0)
            se = tidy_javac(se, tmp, cls)
            if to:
                print(json.dumps(result(verdict="Time limit exceeded", mode=mode, ms=round(ms), stdout=clip(so), error="The program ran longer than %d ms and was stopped." % limit)))
            elif rc != 0:
                print(json.dumps(result(verdict="Runtime error", mode=mode, ms=round(ms), stdout=clip(so), error=clip(se))))
            else:
                print(json.dumps(result(verdict="Finished", mode=mode, ms=round(ms), stdout=clip(so), error=clip(se) or None)))
            return

        body = "\n".join("        test(%d, () -> {\n%s\n        });" % (i, t[1]) for i, t in enumerate(tests))
        hpath = os.path.join(tmp, "Harness.java")
        open(hpath, "w", encoding="utf-8").write(HARNESS.replace("//TESTS//", body))
        rc, so, se, ms, to = run_cmd(["javac", "-encoding", "UTF-8", "-Xlint:none", "-cp", out, "-d", out, hpath], tmp, 60)
        if rc != 0:
            msg = tidy_javac(se or so, tmp, cls).replace("Harness.java:", "tests:")
            print(json.dumps(result(verdict="Compile error", mode=mode, total=len(tests), error="Your code compiled, but the tests could not compile against it. Check the class, method names and signatures the problem asks for.\n\n" + msg, tests=[{"name": t[0], "ok": False, "ran": False, "msg": "", "hidden": bool(len(t) > 2 and t[2])} for t in tests])))
            return

        rc, so, se, ms, to = run_cmd(java_base + ["Harness"], tmp, limit / 1000.0)
        status = {}
        user_out = ""
        for line in so.splitlines():
            if line.startswith("@@P|"):
                status[int(line[4:])] = (True, "")
            elif line.startswith("@@F|"):
                rest = line[4:]
                i, _, m = rest.partition("|")
                status[int(i)] = (False, m)
            elif line.startswith("@@O|"):
                try:
                    user_out = base64.b64decode(line[4:]).decode("utf-8", "replace")
                except Exception:
                    pass
        rows = []
        passed = 0
        for i, t in enumerate(tests):
            s = status.get(i)
            ok = bool(s and s[0])
            passed += 1 if ok else 0
            rows.append({"name": t[0], "ok": ok, "ran": s is not None, "msg": (s[1] if s else ""), "hidden": bool(len(t) > 2 and t[2])})

        err = None
        if to:
            verdict, err = "Time limit exceeded", "The program ran longer than %d ms and was stopped." % limit
        elif rc != 0 and not status:
            verdict, err = "Runtime error", clip(tidy_javac(se, tmp, cls))
        elif passed == len(tests):
            verdict = "Accepted" if mode == "submit" else "Sample tests passed"
        else:
            verdict = "Wrong answer"
            if len(status) < len(tests) and rc == 0:
                err = "The program ended before all tests ran. Does the code call System.exit?"
        if not to and rc != 0 and status and not err:
            err = clip(tidy_javac(se, tmp, cls)) or None
        print(json.dumps(result(**{"verdict": verdict, "mode": mode, "pass": passed, "total": len(tests), "ms": round(ms), "stdout": clip(user_out), "error": err, "tests": rows})))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    main()
